#include "Point.h"

void Point::set(int x, int) {
    this->x = x;
    this->y = y;
}
