#ifndef LAB3_POINT_H
#define LAB3_POINT_H


class Point {
public:
    int x, y;
public:
    void set(int x, int y);
};


#endif
