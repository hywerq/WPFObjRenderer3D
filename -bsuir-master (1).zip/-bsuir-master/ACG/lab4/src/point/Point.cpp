#include "Point.h"


void Point::set(double x, double y, double z) {
    this->x = x;
    this->y = y;
    this->z = z;
}
