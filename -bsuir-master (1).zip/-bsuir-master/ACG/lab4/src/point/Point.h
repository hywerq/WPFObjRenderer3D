#ifndef LAB4_POINT_H
#define LAB4_POINT_H


class Point {
public:
    double x, y, z;
    void set(double x, double y, double z);
};


#endif
